package org.psnbtech;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BoardPanelTest {
	
	Tetris tetris = new Tetris();
	BoardPanel boardPanel = new BoardPanel(tetris);
	Random random = new Random();
	public int TYPE_COUNT =  TileType.values().length;
	public TileType tiletype = TileType.values()[random.nextInt(TYPE_COUNT)];
	//public Random random;

	
	
	@Before
	public void setUp() throws Exception {
		
		}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsValidAndEmpty() {
		boolean testIsValid = boardPanel.isValidAndEmpty(tiletype,3,4,0);
		assertFalse(testIsValid);
	}

	@Test
	public void testAddPiece() {
		;
	}

	@Test
	public void testCheckLines() {
	int i = boardPanel.checkLines();
	assertEquals(0,i);
	}

}
